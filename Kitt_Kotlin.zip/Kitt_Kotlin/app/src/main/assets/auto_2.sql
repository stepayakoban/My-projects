

CREATE TABLE `automobil` (
  `name` varchar(50) NOT NULL PRIMARY KEY,
  `color` varchar(20) DEFAULT NULL,
  `year` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `img` text DEFAULT NULL
) ;



INSERT INTO `automobil` (`name`, `color`, `year`, `price`, `img`) VALUES
('Mercedes-benz  A160', 'metalic', 2011, '27000.00', 'logo0.png'),
('Mercedes-benz B180', 'black', 2016, '24000.00', 'logo0.png'),
('Mercedes-benz C200', 'red', 2015, '27000.00', 'logo0.png'),
('Mercedes-benz CLA250', 'black', 2016, '36000.00', 'logo0.png'),
('Mercedes-benz CLS500', 'black', 2016, '36000.00', 'logo0.png');





