package com.example.kitt_kotlin;

public class Kitt_FragBuilder {
    public Kitt_Frag createKitt_Frag() {
        return new Kitt_Frag();
    }
}