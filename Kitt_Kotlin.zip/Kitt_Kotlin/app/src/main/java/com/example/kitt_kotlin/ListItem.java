package com.example.kitt_kotlin;

public class ListItem {
    private String name;
    private String flag;
    private String  isocode2,isocode3,isocode4;

    public ListItem(String name, String flag, String isocode2, String isocode3, String isocode4)  {
        this.isocode2=isocode2;
        this.isocode3=isocode3;
        this.isocode4=isocode4;
        this.name = name;
        this.flag = flag;

    }

    public String getName() {
        return name;
    }

    public String getIsocode2() {
        return isocode2;
    }

    public String getIsocode3() {
        return isocode3;
    }

    public String getIsocode4() {
        return isocode4;
    }

    public String getFlag() {
        return flag;
    }
}

