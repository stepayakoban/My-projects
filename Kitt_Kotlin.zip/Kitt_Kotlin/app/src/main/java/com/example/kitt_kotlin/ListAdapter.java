package com.example.kitt_kotlin;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;


import com.bumptech.glide.Glide;

import java.util.ArrayList;
import java.util.List;

public class ListAdapter extends ArrayAdapter<ListItem> {
    private Context mContext;

    public ListAdapter(Context context, List<ListItem> items) {
        super(context, 0, items);
        mContext = context;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View listItemView = convertView;
        if (listItemView == null) {
            listItemView = LayoutInflater.from(mContext).inflate(R.layout.list_item, parent, false);
        }

        ListItem currentItem = getItem(position);

        TextView nameTextView = (TextView) listItemView.findViewById(R.id.name_text_view);
        nameTextView.setText(currentItem.getName());
TextView iso3= (TextView) listItemView.findViewById(R.id.iso3_text_view);
iso3.setText(currentItem.getFlag());
        TextView isoTextView = (TextView) listItemView.findViewById(R.id.iso_text_view);
        isoTextView.setText(currentItem.getIsocode2());
        TextView iso1TextView = (TextView) listItemView.findViewById(R.id.iso1_text_view);
        iso1TextView.setText(currentItem.getIsocode3());
       TextView iso3TextView= (TextView) listItemView.findViewById(R.id.iso2_text_view);
iso3TextView.setText(currentItem.getIsocode4());


        return listItemView;
    }
}

