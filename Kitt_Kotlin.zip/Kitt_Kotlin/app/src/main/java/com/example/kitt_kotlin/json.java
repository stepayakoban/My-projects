package com.example.kitt_kotlin;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ListView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class json extends AppCompatActivity {
     List<ListItem> ListItemclass;
    ListView listView;

    @SuppressLint("SuspiciousIndentation")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_json);
         listView =(ListView)  findViewById(R.id.listView);
     ListItemclass = new ArrayList<>();
        loadItemsFromJson();


    }

    private List<ListItem> loadItemsFromJson() {

        String jsonString = "";
        try {
            InputStream inputStream = getAssets().open("sample4.json");
            int size = inputStream.available();
            byte[] buffer = new byte[size];
            inputStream.read(buffer);
            inputStream.close();
            jsonString = new String(buffer, "UTF-8");
        } catch (IOException e) {
            e.printStackTrace();
        }


        List<ListItem> objects = new ArrayList<>();
        try {
            JSONArray jsonArray = new JSONArray(jsonString);
            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject jsonObject = jsonArray.getJSONObject(i);
                ListItem object = new ListItem(jsonObject.getString("firstName"),jsonObject.getString("lastName"),jsonObject.getString("gender"),jsonObject.getString("age"),jsonObject.getString("number"));

                objects.add(object);
            }
            ListAdapter adapter = new ListAdapter(this, objects);
            adapter.notifyDataSetChanged();

            listView.setAdapter(adapter);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return objects;
    }

    public void BackC1lick(View view){
        Intent i=new Intent(json.this, MainActivity.class);
        startActivity(i);
        overridePendingTransition(R.anim.slide_in_up, R.anim.slide_out_down);
    }
}
